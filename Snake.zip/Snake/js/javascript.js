// Game Constants and Variables
let inputDir = {x: 0, y: 0};
// intially snake is not moving
const foodSound = new Audio('music/food.mp3');
const gameOverSound = new Audio('music/gameover.mp3');
const moveSound = new Audio('music/move.mp3');
const musicSound = new Audio('music/music.mp3');
let speed = 5;
let score = 0;
let lastPaintTime = 0;
let snakeArr = [
	{x: 14, y: 15}
]
// food is not array it is single particle where as snake badhta rahega after eating
food = {x: 10, y: 10};



// Game Functions
function main(ctime){
//ctime current time
	window.requestAnimationFrame(main);//main br br call hoga--game loop
	if((ctime - lastPaintTime)/1000 < 1/speed){
		return;
	}
	lastPaintTime = ctime;
	// console.log(ctime);
	gameEngine();//method called to run game
}


function isCollide(snk){
	//if u bump into urself
	for(let j =1; j< snakeArr.length; j++){
		if(snk[j].x === snk[0].x && snk[j].y === snk[0].y){
			return true;
		}
	}
	// if u bump into wall
	if(snk[0].x >= 20 || snk[0].x <= 0 && snk[0].y >= 20 || snk[0].y <= 0){
			return true;
	}
}

function gameEngine(){
	//update variable
	//Part 1 : updating the snake array & Food

	if(isCollide(snakeArr)){
		gameOverSound.play();
		// musicSound.pause();
		inputDir = {x: 0, y: 0};
		alert("Game Over. Press any key to play again!");
		snakeArr = [{x: 14, y: 15}];//reset the snake
		musicSound.play();
		score = 0;
	}
	// IF snake have eaten the food, increment the score and regenerate the food
	if(snakeArr[0].y === food.y && snakeArr[0].x === food.x){
		foodSound.play();
		score += 1;
		if(score > hiscoreval){
			hiscoreval = score;
			localStorage.setItem("hiscore",json.stringfy(hiscoreval));
			HiscoreBox.innerHTML = "HI Score: " + hiscore;
		}
		scorebox.innerHTML = "Score: " + score;
		snakeArr.unshift({x: snakeArr[0].x + inputDir.x, y: snakeArr[0].y + inputDir.y});//jis dir m snake move kr rha h uss dir m add kr diye 
		//The unshift() method adds one or more elements to the beginning of an array and returns the new length of the array.
		let a= 2;
		let b= 18;
		food = {x: Math.round(a + (b-a)*Math.random()), y: Math.round(a + (b-a)* Math.random())}
		// adding food in random way in game---->adding random num bw a&b Math.round(a + (b-a)*Math.random())
	}

	// Moving the snake-->hr segment ko move krenge to move snake
	for(let i = snakeArr.length -2; i>=0; i--){
		snakeArr[i+1] = {...snakeArr[i]};//to avoid reference prob new object jiske andar sirf snk h
	}

	snakeArr[0].x += inputDir.x;
	snakeArr[0].y += inputDir.y;





	//Part 2 : Display/Render the snake and food 

	// Display the Snake
	board.innerHTML = "";//clean the board hume board m ek hi snake chahiye
	snakeArr.forEach((e,index)=>{
		snakeElement = document.createElement('div');
		// displaying snake cord in grid
		snakeElement.style.gridRowStart = e.y;
		snakeElement.style.gridColumnStart = e.x;
	 	
	 	//adding class for showing elements
	 	if(index === 0){
			snakeElement.classList.add('head');
		}
		else
			snakeElement.classList.add('snake');

		board.appendChild(snakeElement);
	})

	// Display the Food element
	foodElement = document.createElement('div');
	foodElement.style.gridRowStart = food.y;
	foodElement.style.gridColumnStart = food.x;
 	//adding class for showing elements
	foodElement.classList.add('food');

	board.appendChild(foodElement);
}





// MAIN logic starts here
let hiscore = localStorage.getItem("hiscore");
if(hiscore == null){
	hiscoreval = 0;
	localStorage.setItem("hiscore",JSON.stringfy(hiscoreval));
}
else{
	hiscoreval = JSON.parse(hiscore);
	HiscoreBox.innerHTML = "HI Score: " + hiscore;
}
/*A common use of JSON is to exchange data to/from a web server.
When receiving data from a web server, the data is always a string.
Convert a JavaScript object into a string with JSON.stringify()
Parse the data with JSON.parse(), and the data becomes a JavaScript object.*/

//game loop br br screen ko paint kiya jata h when we r playing game
window.requestAnimationFrame(main);
// key press hoga toh yeh function run hoga or awaj aygi
window.addEventListener('keydown', e =>{
	inputDir = {x: 0, y: 1} //start the game -->koi v button dabega game start
	moveSound.play();

	// kaun si key press hui h --> e.key
	switch(e.key){
		case "ArrowUp":
			// console.log("ArrowUp")
			inputDir.x = 0;
			inputDir.y = -1;
			break;

		case "ArrowLeft":
			// console.log("ArrowLeft")
			inputDir.x = -1;
			inputDir.y = 0;
			break;

		case "ArrowDown":
			// console.log("ArrowDown")
			inputDir.x = 0;
			inputDir.y = 1;
			break;

		case "ArrowRight":
			// console.log("ArrowUpRight")
			inputDir.x = 1;
			inputDir.y = 0;
			break;

		default:
			break;
	
	}

})